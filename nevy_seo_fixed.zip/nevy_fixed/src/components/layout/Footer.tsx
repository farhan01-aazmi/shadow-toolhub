import Link from 'next/link';
import { Shield, Info, Mail, Twitter, Zap } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="footer">
      <div className="footer-content">
        <div className="footer-section">
          <Link href="/" className="logo">
            <Zap className="logo-icon" size={24} strokeWidth={2.5} />
            <span style={{ fontFamily: 'var(--font-display)', fontWeight: '800' }}>nevy<span style={{ color: 'var(--primary)' }}>.in</span></span>
          </Link>
          <p className="footer-desc">
            150+ free online tools — image, PDF, calculators, crypto & more. No signup, no fees. Ever.
          </p>
        </div>

        <div className="footer-section">
          <h4>Explore Tools</h4>
          <Link href="/tools/currency-converter">Currency Converter</Link>
          <Link href="/tools/crypto-tracker">Crypto Tracker</Link>
          <Link href="/tools/image-optimizer">Image Optimizer</Link>
          <Link href="/tools/loan-calculator">Loan Calculator</Link>
          <Link href="/tools/word-counter">Word Counter</Link>
          <Link href="/tools/meta-generator">Meta Generator</Link>
        </div>

        <div className="footer-section">
          <h4>Company</h4>
          <Link href="/about">About Us</Link>
          <Link href="/blog">Blog</Link>
          <Link href="/contact">Contact Us</Link>
        </div>

        <div className="footer-section">
          <h4>Legal</h4>
          <Link href="/privacy">Privacy Policy</Link>
          <Link href="/terms">Terms of Service</Link>
        </div>
      </div>

      <div className="footer-bottom">
        <p>&copy; {new Date().getFullYear()} nevy.in — All rights reserved. | Mumbai, Maharashtra, India</p>
      </div>
    </footer>
  );
}
