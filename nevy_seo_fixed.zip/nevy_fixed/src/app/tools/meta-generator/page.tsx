'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { Search, Zap, HelpCircle, ChevronRight, Copy, Check, Lightbulb } from 'lucide-react';

export default function MetaGeneratorPage() {
    const [meta, setMeta] = useState({ title: '', description: '', keywords: '', author: '', robots: 'index, follow' });
    const [copied, setCopied] = useState(false);

    const titleLen = meta.title.length;
    const descLen = meta.description.length;
    const titleStatus = titleLen === 0 ? '' : titleLen < 30 ? '⚠️ Too short' : titleLen <= 60 ? '✅ Perfect' : '⚠️ Too long';
    const descStatus = descLen === 0 ? '' : descLen < 70 ? '⚠️ Too short' : descLen <= 160 ? '✅ Perfect' : '⚠️ Too long';

    const generateCode = () => `<!-- Primary Meta Tags -->
<title>${meta.title}</title>
<meta name="title" content="${meta.title}">
<meta name="description" content="${meta.description}">
<meta name="keywords" content="${meta.keywords}">
<meta name="author" content="${meta.author}">
<meta name="robots" content="${meta.robots}">

<!-- Open Graph / Facebook / WhatsApp -->
<meta property="og:type" content="website">
<meta property="og:title" content="${meta.title}">
<meta property="og:description" content="${meta.description}">

<!-- Twitter -->
<meta property="twitter:card" content="summary_large_image">
<meta property="twitter:title" content="${meta.title}">
<meta property="twitter:description" content="${meta.description}">`;

    const copyToClipboard = () => {
        navigator.clipboard.writeText(generateCode());
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
    };

    return (
        <div className="tool-container">
            <nav className="breadcrumb">
                <Link href="/">Home</Link> / <span>Meta Tag Generator</span>
            </nav>

            <header className="tool-header">
                <div className="tool-category">SEO</div>
                <h1>Free <span className="gradient-text">Meta Tag Generator</span></h1>
                <p className="tool-intro">
                    Generate complete, SEO-optimized meta tags for any webpage — including title, description,
                    Open Graph, and Twitter card tags. Includes a live Google search preview and character
                    count indicators. Copy the code in one click. No signup needed.
                </p>
            </header>

            <div className="tool-layout">
                <div className="tool-main">
                    <div className="card">
                        <div className="meta-form">
                            <div className="input-group">
                                <label>Page Title <span style={{ color: titleStatus.includes('✅') ? '#38A169' : '#E53E3E' }}>{titleStatus}</span></label>
                                <input type="text" placeholder="e.g. Free Currency Converter — Live Exchange Rates | nevy.in" className="premium-input" value={meta.title} onChange={(e) => setMeta({ ...meta, title: e.target.value })} />
                                <small style={{ color: titleLen > 60 ? '#E53E3E' : 'var(--text-muted)' }}>{titleLen} / 60 characters recommended</small>
                            </div>
                            <div className="input-group" style={{ marginTop: '20px' }}>
                                <label>Meta Description <span style={{ color: descStatus.includes('✅') ? '#38A169' : '#E53E3E' }}>{descStatus}</span></label>
                                <textarea placeholder="e.g. Convert 150+ currencies with real-time exchange rates for free. No signup needed." className="premium-input" style={{ minHeight: '90px' }} value={meta.description} onChange={(e) => setMeta({ ...meta, description: e.target.value })} />
                                <small style={{ color: descLen > 160 ? '#E53E3E' : 'var(--text-muted)' }}>{descLen} / 160 characters recommended</small>
                            </div>
                            <div className="input-group" style={{ marginTop: '20px' }}>
                                <label>Keywords (comma separated)</label>
                                <input type="text" placeholder="e.g. currency converter, exchange rates, USD to INR" className="premium-input" value={meta.keywords} onChange={(e) => setMeta({ ...meta, keywords: e.target.value })} />
                            </div>
                            <div className="input-group" style={{ marginTop: '20px' }}>
                                <label>Author Name</label>
                                <input type="text" placeholder="e.g. nevy.in Team" className="premium-input" value={meta.author} onChange={(e) => setMeta({ ...meta, author: e.target.value })} />
                            </div>
                        </div>
                    </div>

                    <div className="card result-card" style={{ marginTop: '32px' }}>
                        <div className="result-header">
                            <h3>Generated HTML Tags</h3>
                            <button className="btn btn-outline" onClick={copyToClipboard} style={{ padding: '8px 16px' }}>
                                {copied ? <Check size={16} color="var(--primary)" /> : <Copy size={16} />}
                                {copied ? 'Copied!' : 'Copy All Tags'}
                            </button>
                        </div>
                        <pre className="code-output">{generateCode()}</pre>
                    </div>
                </div>

                <div className="tool-sidebar">
                    <div className="card preview-card">
                        <h3>Google Search Preview</h3>
                        <div className="search-preview">
                            <div className="preview-url">www.yourdomain.com</div>
                            <div className="preview-title">{meta.title || 'Your Page Title Appears Here'}</div>
                            <div className="preview-desc">{meta.description || 'Your meta description will appear here in search results. Make it compelling and include your main keyword.'}</div>
                        </div>
                    </div>

                    <div className="card tip-card" style={{ marginTop: '16px' }}>
                        <div className="tip-header">
                            <Lightbulb size={16} color="var(--primary)" />
                            <span>Writing Tips</span>
                        </div>
                        <ul style={{ fontSize: '13px', color: 'var(--text-muted)', lineHeight: '1.8', paddingLeft: '16px' }}>
                            <li>Put your main keyword near the start of the title</li>
                            <li>Include a clear benefit in the description</li>
                            <li>End description with a call to action</li>
                            <li>Avoid duplicate titles across pages</li>
                        </ul>
                    </div>
                </div>
            </div>

            <section className="card glass" style={{ marginTop: '40px', padding: '32px' }}>
                <h2>Which Meta Tags Still Matter in 2025?</h2>
                <p style={{ marginTop: '12px', lineHeight: '1.8' }}>
                    The <strong>title tag</strong> remains the most important meta element — it directly affects rankings and click-through rates.
                    The <strong>meta description</strong> does not directly affect rankings, but a compelling description dramatically increases clicks from search results, which indirectly helps rankings.
                    The <strong>keywords meta tag</strong> has been ignored by Google since 2009, but it is harmless to include.
                    <strong>Open Graph tags</strong> (og:title, og:description, og:image) are essential for social sharing — without them, WhatsApp, Twitter, and Facebook generate incorrect previews.
                </p>
            </section>

            <section className="faq-section" style={{ marginTop: '40px' }}>
                <h2><HelpCircle size={20} style={{ display: 'inline', marginRight: '8px' }} />Frequently Asked Questions</h2>
                <div className="faq-list" style={{ marginTop: '20px' }}>
                    {[
                        { q: "What is the ideal title tag length?", a: "Keep title tags between 50-60 characters. Google typically displays up to 60 characters in search results. Longer titles get truncated with '...'." },
                        { q: "What is the ideal meta description length?", a: "Meta descriptions should be 150-160 characters. Shorter ones miss the opportunity to add context. Longer ones get cut off in search results." },
                        { q: "Do meta keywords affect Google rankings?", a: "No. Google officially stopped reading the keywords meta tag in 2009. Focus all your keyword optimization on your title, description, and actual page content." },
                        { q: "What are Open Graph tags?", a: "Open Graph tags (og:title, og:description, og:image) control how your page looks when shared on Facebook, WhatsApp, Twitter, and LinkedIn. They are separate from standard meta tags." },
                        { q: "Should every page have unique meta tags?", a: "Yes, absolutely. Duplicate meta titles and descriptions across multiple pages confuse Google and can hurt your rankings. Every page should have unique, specific tags." },
                        { q: "What is the robots meta tag?", a: "The robots meta tag tells search engines whether to index the page and follow its links. 'index, follow' is the default and tells Google to index the page normally." },
                    ].map((item, i) => (
                        <details key={i} className="faq-item card" style={{ marginBottom: '12px', padding: '16px 20px' }}>
                            <summary style={{ fontWeight: '600', cursor: 'pointer', listStyle: 'none' }}>
                                <ChevronRight size={16} style={{ display: 'inline', marginRight: '8px' }} />{item.q}
                            </summary>
                            <p style={{ marginTop: '10px', color: 'var(--text-muted)', lineHeight: '1.7' }}>{item.a}</p>
                        </details>
                    ))}
                </div>
            </section>

            <section className="related-tools card glass" style={{ marginTop: '32px', padding: '24px' }}>
                <h3>Related Tools</h3>
                <div style={{ display: 'flex', gap: '12px', marginTop: '16px', flexWrap: 'wrap' }}>
                    <Link href="/tools/word-counter" className="btn btn-secondary">Word Counter <ChevronRight size={14} /></Link>
                    <Link href="/tools/image-optimizer" className="btn btn-secondary">Image Optimizer <ChevronRight size={14} /></Link>
                    <Link href="/tools/currency-converter" className="btn btn-secondary">Currency Converter <ChevronRight size={14} /></Link>
                </div>
            </section>

            <style jsx>{`
                .premium-input { width: 100%; background: #111418; border: 1px solid var(--card-border); border-radius: 8px; padding: 12px 16px; color: white; outline: none; transition: border-color 0.2s; font-family: inherit; }
                .premium-input:focus { border-color: var(--primary); }
                .input-group label { display: block; font-size: 14px; font-weight: 600; margin-bottom: 8px; }
                .input-group small { display: block; margin-top: 6px; font-size: 11px; color: var(--text-muted); }
                .result-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; }
                .code-output { background: #050505; padding: 24px; border-radius: 8px; font-size: 12px; color: #94a3b8; white-space: pre-wrap; overflow-x: auto; border: 1px solid #1a1a1a; font-family: monospace; line-height: 1.6; }
                .search-preview { margin-top: 16px; background: #fff; padding: 16px; border-radius: 8px; }
                .preview-url { color: #202124; font-size: 12px; margin-bottom: 2px; }
                .preview-title { color: #1a0dab; font-size: 18px; margin-bottom: 6px; font-weight: 400; }
                .preview-desc { color: #4d5156; font-size: 14px; line-height: 1.4; }
                .tip-header { display: flex; align-items: center; gap: 8px; margin-bottom: 10px; font-weight: 700; font-size: 14px; }
            `}</style>
        </div>
    );
}
