import { Metadata } from 'next';
import { getTopCoins } from '@/lib/api/crypto';
import CryptoDashboard from './CryptoDashboard';
import StructuredData from '@/components/seo/StructuredData';
import Link from 'next/link';
import { Shield, TrendingUp, BarChart3, Zap, HelpCircle, ChevronRight } from 'lucide-react';

export const metadata: Metadata = {
    title: "Live Crypto Price Tracker — Bitcoin, Ethereum & Top 50 Coins | nevy.in",
    description: "Track live cryptocurrency prices, market cap, 24h change and trading volume for Bitcoin, Ethereum and 50+ altcoins. Free, real-time crypto tracker. No signup needed.",
    keywords: ["crypto tracker", "bitcoin price today", "ethereum price live", "crypto market cap", "live cryptocurrency prices India", "altcoin tracker free"],
    alternates: { canonical: "https://www.nevy.in/tools/crypto-tracker" },
};

export default async function CryptoTrackerPage() {
    const coins = await getTopCoins(50);

    const schemaData = {
        "@context": "https://schema.org",
        "@type": "WebApplication",
        "name": "Crypto Price Tracker",
        "url": "https://www.nevy.in/tools/crypto-tracker",
        "applicationCategory": "FinanceApplication",
        "operatingSystem": "Web Browser",
        "offers": { "@type": "Offer", "price": "0", "priceCurrency": "INR" },
        "description": "Free real-time cryptocurrency price tracker for top 50 coins including Bitcoin and Ethereum.",
        "provider": { "@type": "Organization", "name": "nevy.in", "url": "https://www.nevy.in" }
    };

    const faqSchema = {
        "@context": "https://schema.org",
        "@type": "FAQPage",
        "mainEntity": [
            { "@type": "Question", "name": "How often does the crypto tracker update prices?", "acceptedAnswer": { "@type": "Answer", "text": "Prices update every 5 minutes using the CoinGecko API, giving you near real-time market data for all tracked coins." } },
            { "@type": "Question", "name": "Which cryptocurrencies are tracked?", "acceptedAnswer": { "@type": "Answer", "text": "We track the top 50 cryptocurrencies by market cap, including Bitcoin (BTC), Ethereum (ETH), Solana (SOL), BNB, XRP, and more." } },
            { "@type": "Question", "name": "Is this crypto tracker free to use?", "acceptedAnswer": { "@type": "Answer", "text": "Yes, completely free. No signup, no subscription, no hidden fees." } },
            { "@type": "Question", "name": "What does the 24h change percentage mean?", "acceptedAnswer": { "@type": "Answer", "text": "The 24h change shows how much the coin's price has moved in the last 24 hours as a percentage. A positive number means the price went up, negative means it went down." } },
            { "@type": "Question", "name": "What is market cap in crypto?", "acceptedAnswer": { "@type": "Answer", "text": "Market cap is the total value of all coins in circulation, calculated as price × circulating supply. It is the best indicator of a cryptocurrency's overall size and dominance." } },
        ]
    };

    if (!coins || coins.length === 0) {
        return (
            <div className="error-container card">
                <h2>Crypto Market Data Unavailable</h2>
                <p>We are experiencing a delay fetching live market data. Please refresh the page in a moment.</p>
            </div>
        );
    }

    return (
        <>
        <StructuredData data={schemaData} />
        <StructuredData data={faqSchema} />
        <div className="tool-container">
            <nav className="breadcrumb">
                <Link href="/">Home</Link> / <span>Crypto Tracker</span>
            </nav>

            <header className="tool-header">
                <div className="tool-category">Crypto</div>
                <h1>Live <span className="gradient-text">Crypto Price Tracker</span></h1>
                <p className="tool-intro">
                    Real-time prices, market cap, trading volume, and 24-hour change for Bitcoin, Ethereum,
                    and the top 50 cryptocurrencies. Data sourced from CoinGecko, updated every 5 minutes.
                    Free — no account required.
                </p>
            </header>

            <div className="dashboard-wrapper">
                <CryptoDashboard initialCoins={coins} />
            </div>

            <section className="seo-content-grid" style={{ marginTop: '48px' }}>
                <div className="card glass">
                    <TrendingUp className="text-secondary" size={28} />
                    <h3>Real-Time Market Data</h3>
                    <p>Prices refresh every 5 minutes from the CoinGecko API — one of the most trusted cryptocurrency data sources globally. Always accurate, always current.</p>
                </div>
                <div className="card glass">
                    <BarChart3 className="text-primary" size={28} />
                    <h3>Full Market Metrics</h3>
                    <p>See market cap, 24h trading volume, price change, and market rank for every coin. These numbers matter far more than price alone when evaluating any cryptocurrency.</p>
                </div>
                <div className="card glass">
                    <Shield className="text-accent" size={28} />
                    <h3>No Login, No Tracking</h3>
                    <p>We do not require an account, email, or any personal information. Your searches and views remain completely private.</p>
                </div>
            </section>

            <section className="card glass" style={{ marginTop: '32px', padding: '32px' }}>
                <h2>How to Read Crypto Market Data</h2>
                <p style={{ marginTop: '12px', lineHeight: '1.8' }}>
                    When tracking any cryptocurrency, focus on four numbers: <strong>Price</strong> tells you the current cost per coin.
                    <strong> Market Cap</strong> (price × circulating supply) shows the coin's real size — a higher market cap means more stability.
                    <strong> 24h Volume</strong> confirms whether a price move is genuine — high volume on a surge is bullish, low volume is suspicious.
                    <strong> 24h Change</strong> shows today's direction as a percentage. Click any coin for a detailed breakdown of all its metrics.
                </p>
            </section>

            <section className="faq-section" style={{ marginTop: '40px' }}>
                <h2><HelpCircle size={20} style={{ display: 'inline', marginRight: '8px' }} />Frequently Asked Questions</h2>
                <div className="faq-list" style={{ marginTop: '20px' }}>
                    {[
                        { q: "How often does the crypto tracker update?", a: "Prices update every 5 minutes using the CoinGecko API, giving you near real-time data for all tracked coins." },
                        { q: "Which cryptocurrencies are covered?", a: "We track the top 50 coins by market cap — including Bitcoin, Ethereum, Solana, BNB, XRP, Cardano, Dogecoin, and more." },
                        { q: "Is this tracker free?", a: "Yes, 100% free. No signup, no subscription, no fees. Ever." },
                        { q: "What does 24h change mean?", a: "It shows how much the price has moved in the last 24 hours as a percentage. Green means up, red means down." },
                        { q: "What is market cap and why does it matter?", a: "Market cap = price × circulating supply. It is the most reliable indicator of a coin's size and institutional confidence. Always compare market caps, not just prices." },
                    ].map((item, i) => (
                        <details key={i} className="faq-item card" style={{ marginBottom: '12px', padding: '16px 20px' }}>
                            <summary style={{ fontWeight: '600', cursor: 'pointer', listStyle: 'none' }}>
                                <ChevronRight size={16} style={{ display: 'inline', marginRight: '8px' }} />{item.q}
                            </summary>
                            <p style={{ marginTop: '10px', color: 'var(--text-muted)', lineHeight: '1.7' }}>{item.a}</p>
                        </details>
                    ))}
                </div>
            </section>

            <section className="related-tools card glass" style={{ marginTop: '32px', padding: '24px' }}>
                <h3>Related Tools</h3>
                <div style={{ display: 'flex', gap: '12px', marginTop: '16px', flexWrap: 'wrap' }}>
                    <Link href="/tools/currency-converter" className="btn btn-secondary">Currency Converter <ChevronRight size={14} /></Link>
                    <Link href="/tools/loan-calculator" className="btn btn-secondary">Loan Calculator <ChevronRight size={14} /></Link>
                    <Link href="/tools/meta-generator" className="btn btn-secondary">Meta Tag Generator <ChevronRight size={14} /></Link>
                </div>
            </section>
        </div>
        </>
    );
}
