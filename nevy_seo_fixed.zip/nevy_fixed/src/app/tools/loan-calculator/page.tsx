import { Metadata } from 'next';
import LoanCalculatorComponent from './LoanCalculatorComponent';
import StructuredData from '@/components/seo/StructuredData';
import Link from 'next/link';
import { ShieldCheck, TrendingUp, Calculator, HelpCircle, ChevronRight, Info } from 'lucide-react';

export const metadata: Metadata = {
    title: "Free EMI & Loan Calculator India — Home Loan, Personal Loan, Car Loan | nevy.in",
    description: "Calculate EMI, total interest, and complete payment schedule for home loans, personal loans, and car loans. Free Indian EMI calculator with amortization chart. No signup.",
    keywords: ["EMI calculator India", "home loan EMI calculator", "personal loan calculator", "car loan EMI", "loan interest calculator India", "free EMI calculator"],
    alternates: { canonical: "https://www.nevy.in/tools/loan-calculator" },
};

export default function LoanCalculatorPage() {

    const schemaData = {
        "@context": "https://schema.org",
        "@type": "WebApplication",
        "name": "EMI & Loan Calculator",
        "url": "https://www.nevy.in/tools/loan-calculator",
        "applicationCategory": "FinanceApplication",
        "operatingSystem": "Web Browser",
        "offers": { "@type": "Offer", "price": "0", "priceCurrency": "INR" },
        "description": "Free Indian EMI calculator for home loans, personal loans, and car loans with full amortization schedule.",
        "provider": { "@type": "Organization", "name": "nevy.in", "url": "https://www.nevy.in" }
    };

    const faqSchema = {
        "@context": "https://schema.org",
        "@type": "FAQPage",
        "mainEntity": [
            { "@type": "Question", "name": "What is EMI?", "acceptedAnswer": { "@type": "Answer", "text": "EMI stands for Equated Monthly Instalment. It is the fixed monthly amount you pay to your bank to repay a loan over a set period. Each EMI payment includes both principal repayment and interest charges." } },
            { "@type": "Question", "name": "How is EMI calculated?", "acceptedAnswer": { "@type": "Answer", "text": "EMI = P × r × (1+r)^n / ((1+r)^n - 1), where P is the principal loan amount, r is the monthly interest rate (annual rate divided by 12), and n is the loan tenure in months." } },
            { "@type": "Question", "name": "What is the current home loan interest rate in India?", "acceptedAnswer": { "@type": "Answer", "text": "Home loan interest rates in India typically range from 8.35% to 10.5% per annum depending on the lender, your credit score, and the loan amount. Use our calculator to compare EMIs at different rates." } },
            { "@type": "Question", "name": "How can I reduce my EMI?", "acceptedAnswer": { "@type": "Answer", "text": "You can reduce EMI by making a larger down payment, choosing a longer repayment tenure, negotiating a lower interest rate, or prepaying part of the principal when possible." } },
            { "@type": "Question", "name": "What is an amortization schedule?", "acceptedAnswer": { "@type": "Answer", "text": "An amortization schedule shows the month-by-month breakdown of each EMI payment into principal and interest components. In early months, most of the EMI goes toward interest. Over time, more goes toward reducing the principal." } },
            { "@type": "Question", "name": "Can I use this calculator for personal loans and car loans?", "acceptedAnswer": { "@type": "Answer", "text": "Yes. The EMI formula is the same for all flat-rate amortizing loans — home loans, personal loans, car loans, and business loans. Just enter the correct interest rate for your specific loan type." } },
        ]
    };

    return (
        <>
        <StructuredData data={schemaData} />
        <StructuredData data={faqSchema} />
        <div className="tool-container">
            <nav className="breadcrumb">
                <Link href="/">Home</Link> / <span>EMI & Loan Calculator</span>
            </nav>

            <header className="tool-header">
                <div className="tool-category">Finance</div>
                <h1>Free <span className="gradient-text">EMI & Loan Calculator</span></h1>
                <p className="tool-intro">
                    Calculate the exact monthly EMI, total interest payable, and complete repayment schedule
                    for any loan — home loan, personal loan, or car loan. Enter your loan amount, interest rate,
                    and tenure to get an instant, accurate breakdown. No signup required.
                </p>
            </header>

            <LoanCalculatorComponent />

            <section className="card glass" style={{ marginTop: '40px', padding: '32px' }}>
                <h2><Info size={20} style={{ display: 'inline', marginRight: '8px' }} />Understanding Your EMI Calculation</h2>
                <p style={{ marginTop: '16px', lineHeight: '1.8' }}>
                    Every EMI payment you make has two parts: <strong>principal repayment</strong> and <strong>interest payment</strong>.
                    In the early months of a loan, most of your EMI goes toward paying interest. As time passes, a larger portion goes toward reducing the actual loan balance.
                    This is why prepaying even a small amount early in the loan tenure saves disproportionately large amounts of total interest.
                </p>
                <p style={{ marginTop: '12px', lineHeight: '1.8' }}>
                    For example: A ₹50 lakh home loan at 8.75% for 20 years has a monthly EMI of approximately ₹44,028.
                    You will pay ₹1,05,66,720 total — meaning ₹55,66,720 in interest on top of the principal.
                    Reducing the tenure to 15 years increases the EMI to ₹49,925 but saves over ₹18 lakhs in total interest.
                </p>
            </section>

            <section className="seo-benefits-grid card glass" style={{ marginTop: '32px' }}>
                <h2>Tips to Reduce Your Total Loan Cost</h2>
                <div className="benefits-row" style={{ marginTop: '20px' }}>
                    <div className="benefit-item">
                        <Calculator size={24} className="text-primary" />
                        <div>
                            <h3>Make a Larger Down Payment</h3>
                            <p>Every extra rupee in down payment reduces your principal. A 5% additional down payment on a ₹1 crore home can save over ₹8 lakhs in interest over 20 years.</p>
                        </div>
                    </div>
                    <div className="benefit-item">
                        <TrendingUp size={24} className="text-secondary" />
                        <div>
                            <h3>Compare Lenders Before Signing</h3>
                            <p>A 0.5% difference in interest rate on a ₹50 lakh 20-year loan equals approximately ₹3.5 lakh in additional total interest. Always compare multiple lenders.</p>
                        </div>
                    </div>
                    <div className="benefit-item">
                        <ShieldCheck size={24} className="text-accent" />
                        <div>
                            <h3>Prepay When Possible</h3>
                            <p>Even one extra EMI per year significantly reduces your loan tenure and total interest. Many banks allow prepayment without penalty on floating rate loans.</p>
                        </div>
                    </div>
                </div>
            </section>

            <section className="faq-section" style={{ marginTop: '40px' }}>
                <h2><HelpCircle size={20} style={{ display: 'inline', marginRight: '8px' }} />Frequently Asked Questions</h2>
                <div className="faq-list" style={{ marginTop: '20px' }}>
                    {[
                        { q: "What is EMI?", a: "EMI (Equated Monthly Instalment) is the fixed monthly payment you make to repay a loan. Each EMI includes both principal repayment and the interest charged for that month." },
                        { q: "How is EMI calculated?", a: "EMI = P × r × (1+r)^n / ((1+r)^n - 1), where P = loan principal, r = monthly interest rate (annual rate ÷ 12), n = tenure in months." },
                        { q: "What is the typical home loan rate in India in 2025?", a: "Home loan rates in India typically range from 8.35% to 10.5% per annum depending on the lender and your credit score. RBI repo rate changes directly impact floating rate home loans." },
                        { q: "How can I reduce my EMI amount?", a: "You can reduce EMI by making a larger down payment, increasing the loan tenure, negotiating a lower rate, or making periodic prepayments to reduce the outstanding principal." },
                        { q: "What is an amortization schedule?", a: "An amortization schedule shows the month-by-month split of each EMI into principal and interest. Early payments are mostly interest — this is why early prepayment saves the most money." },
                        { q: "Can I use this for car loans and personal loans?", a: "Yes. The EMI formula is the same for all flat-rate loans — home loans, car loans, personal loans, and business loans. Just enter the correct rate for your loan type." },
                    ].map((item, i) => (
                        <details key={i} className="faq-item card" style={{ marginBottom: '12px', padding: '16px 20px' }}>
                            <summary style={{ fontWeight: '600', cursor: 'pointer', listStyle: 'none' }}>
                                <ChevronRight size={16} style={{ display: 'inline', marginRight: '8px' }} />{item.q}
                            </summary>
                            <p style={{ marginTop: '10px', color: 'var(--text-muted)', lineHeight: '1.7' }}>{item.a}</p>
                        </details>
                    ))}
                </div>
            </section>

            <section className="related-tools card glass" style={{ marginTop: '32px', padding: '24px' }}>
                <h3>Related Tools</h3>
                <div style={{ display: 'flex', gap: '12px', marginTop: '16px', flexWrap: 'wrap' }}>
                    <Link href="/tools/currency-converter" className="btn btn-secondary">Currency Converter <ChevronRight size={14} /></Link>
                    <Link href="/tools/crypto-tracker" className="btn btn-secondary">Crypto Tracker <ChevronRight size={14} /></Link>
                    <Link href="/tools/word-counter" className="btn btn-secondary">Word Counter <ChevronRight size={14} /></Link>
                </div>
            </section>
        </div>
        </>
    );
}
