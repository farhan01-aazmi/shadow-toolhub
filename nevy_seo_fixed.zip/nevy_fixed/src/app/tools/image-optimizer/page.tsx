import { Metadata } from 'next';
import OptimizerComponent from './OptimizerComponent';
import StructuredData from '@/components/seo/StructuredData';
import Link from 'next/link';
import { ShieldCheck, Zap, Globe, HardDrive, HelpCircle, ChevronRight } from 'lucide-react';

export const metadata: Metadata = {
    title: "Free Image Optimizer — Compress JPEG, PNG & Convert to WebP | nevy.in",
    description: "Compress and convert images to WebP, JPEG or PNG for free. Reduce image file size by up to 90% without losing quality. 100% browser-based — files never leave your device.",
    keywords: ["image optimizer", "compress image online free", "convert image to webp", "reduce image size", "free image compressor India", "jpeg to webp"],
    alternates: { canonical: "https://www.nevy.in/tools/image-optimizer" },
};

export default function ImageOptimizerPage() {

    const schemaData = {
        "@context": "https://schema.org",
        "@type": "WebApplication",
        "name": "Image Optimizer",
        "url": "https://www.nevy.in/tools/image-optimizer",
        "applicationCategory": "MultimediaApplication",
        "operatingSystem": "Web Browser",
        "offers": { "@type": "Offer", "price": "0", "priceCurrency": "INR" },
        "description": "Free browser-based image optimizer. Compress JPEG, PNG, WebP without uploading to any server.",
        "provider": { "@type": "Organization", "name": "nevy.in", "url": "https://www.nevy.in" }
    };

    const faqSchema = {
        "@context": "https://schema.org",
        "@type": "FAQPage",
        "mainEntity": [
            { "@type": "Question", "name": "Does this tool upload my images to a server?", "acceptedAnswer": { "@type": "Answer", "text": "No. Processing happens entirely inside your browser using the HTML5 Canvas API. Your images never leave your device." } },
            { "@type": "Question", "name": "What image formats are supported?", "acceptedAnswer": { "@type": "Answer", "text": "You can upload JPEG, PNG, and WebP images. You can convert to WebP, JPEG, or PNG output formats." } },
            { "@type": "Question", "name": "How much can I reduce my image size?", "acceptedAnswer": { "@type": "Answer", "text": "At 80% quality setting, most images reduce by 60-90% in file size with no visible quality loss on screens." } },
            { "@type": "Question", "name": "What quality setting should I use for websites?", "acceptedAnswer": { "@type": "Answer", "text": "80% quality is the recommended sweet spot for web images — significant file size reduction with no perceptible visual difference." } },
            { "@type": "Question", "name": "Why should I convert images to WebP?", "acceptedAnswer": { "@type": "Answer", "text": "WebP files are 25-34% smaller than JPEG and 26% smaller than PNG at equivalent quality. This directly improves page load speed and Google Core Web Vitals scores." } },
            { "@type": "Question", "name": "Is there a file size limit?", "acceptedAnswer": { "@type": "Answer", "text": "Since processing happens in your browser, the practical limit depends on your device's RAM. Most modern devices handle images up to 20MB without issues." } },
        ]
    };

    return (
        <>
        <StructuredData data={schemaData} />
        <StructuredData data={faqSchema} />
        <div className="tool-container">
            <nav className="breadcrumb">
                <Link href="/">Home</Link> / <span>Image Optimizer</span>
            </nav>

            <header className="tool-header">
                <div className="tool-category">Image</div>
                <h1>Free <span className="gradient-text">Image Optimizer</span></h1>
                <p className="tool-intro">
                    Compress JPEG, PNG, and WebP images by up to 90% without losing visible quality.
                    Converts to WebP for maximum web performance. 100% browser-based —
                    your images never leave your device. No upload. No account. Instant results.
                </p>
            </header>

            <OptimizerComponent />

            <section className="how-it-works" style={{ marginTop: '40px' }}>
                <h2>How to Use the Image Optimizer</h2>
                <div className="steps-cards" style={{ marginTop: '20px' }}>
                    <div className="step card">
                        <span className="step-num">01</span>
                        <h4>Upload Your Image</h4>
                        <p>Drag and drop your JPEG, PNG or WebP image onto the tool, or click to browse your files.</p>
                    </div>
                    <div className="step card">
                        <span className="step-num">02</span>
                        <h4>Choose Format & Quality</h4>
                        <p>Select WebP for websites, JPEG for photos, or PNG for graphics. Adjust the quality slider — 80% works for most cases.</p>
                    </div>
                    <div className="step card">
                        <span className="step-num">03</span>
                        <h4>Download Instantly</h4>
                        <p>Your optimized image downloads immediately. Compare the before/after file sizes to see how much you saved.</p>
                    </div>
                </div>
            </section>

            <section className="seo-benefits-grid card glass" style={{ marginTop: '32px' }}>
                <h2>Why Image Optimization Matters for SEO</h2>
                <div className="benefits-row" style={{ marginTop: '20px' }}>
                    <div className="benefit-item">
                        <Globe size={24} className="text-secondary" />
                        <div>
                            <h3>Faster Page Load Speed</h3>
                            <p>Images are 60-80% of a page's total weight. Optimizing them is the single fastest way to improve load times. Google rewards faster pages with better rankings.</p>
                        </div>
                    </div>
                    <div className="benefit-item">
                        <Zap size={24} className="text-primary" />
                        <div>
                            <h3>Better Core Web Vitals</h3>
                            <p>LCP (Largest Contentful Paint) — a key Google ranking signal — is almost always an image. An optimized hero image can improve your LCP score from "Poor" to "Good" instantly.</p>
                        </div>
                    </div>
                    <div className="benefit-item">
                        <HardDrive size={24} className="text-accent" />
                        <div>
                            <h3>Lower Hosting Costs</h3>
                            <p>Smaller images mean less bandwidth usage. For high-traffic websites, this directly reduces CDN and hosting costs every single month.</p>
                        </div>
                    </div>
                    <div className="benefit-item">
                        <ShieldCheck size={24} className="text-secondary" />
                        <div>
                            <h3>Complete Privacy</h3>
                            <p>Unlike other tools that upload your images to their servers, everything here runs in your browser. Your personal photos and business assets stay 100% private.</p>
                        </div>
                    </div>
                </div>
            </section>

            <section className="card glass" style={{ marginTop: '32px', padding: '32px' }}>
                <h2>WebP vs JPEG vs PNG — Which Format to Choose?</h2>
                <p style={{ marginTop: '12px', lineHeight: '1.8' }}>
                    <strong>WebP</strong> is the best choice for almost all web images — it is 25-34% smaller than JPEG and 26% smaller than PNG at equivalent quality.
                    All modern browsers support it. Use WebP for website hero images, product photos, and blog thumbnails.
                </p>
                <p style={{ marginTop: '12px', lineHeight: '1.8' }}>
                    <strong>JPEG</strong> is best for photographs where you need maximum compatibility — email attachments, older CMS platforms, or social media uploads that do not accept WebP.
                </p>
                <p style={{ marginTop: '12px', lineHeight: '1.8' }}>
                    <strong>PNG</strong> is ideal for images with transparency (logos, icons, UI elements) or graphics with sharp edges where JPEG compression creates visible artifacts.
                </p>
            </section>

            <section className="faq-section" style={{ marginTop: '40px' }}>
                <h2><HelpCircle size={20} style={{ display: 'inline', marginRight: '8px' }} />Frequently Asked Questions</h2>
                <div className="faq-list" style={{ marginTop: '20px' }}>
                    {[
                        { q: "Does this tool upload my images to a server?", a: "No. All processing happens inside your browser using the HTML5 Canvas API. Your images never leave your device — 100% private." },
                        { q: "What formats are supported?", a: "Upload: JPEG, PNG, WebP. Output: WebP, JPEG, or PNG. You can convert between any of these formats." },
                        { q: "How much can I reduce my image size?", a: "At 80% quality, most images reduce by 60-90% in file size with no visible difference on screen." },
                        { q: "What quality setting should I use for websites?", a: "80% is the recommended setting for web images — a 60-80% file size reduction with no perceptible visual loss." },
                        { q: "Why should I convert images to WebP?", a: "WebP files are 25-34% smaller than JPEG at equivalent quality. This directly improves page load speed and Google Core Web Vitals scores." },
                        { q: "Is there a file size limit?", a: "No server-side limit exists since everything runs in your browser. Most devices handle images up to 20MB easily." },
                    ].map((item, i) => (
                        <details key={i} className="faq-item card" style={{ marginBottom: '12px', padding: '16px 20px' }}>
                            <summary style={{ fontWeight: '600', cursor: 'pointer', listStyle: 'none' }}>
                                <ChevronRight size={16} style={{ display: 'inline', marginRight: '8px' }} />{item.q}
                            </summary>
                            <p style={{ marginTop: '10px', color: 'var(--text-muted)', lineHeight: '1.7' }}>{item.a}</p>
                        </details>
                    ))}
                </div>
            </section>

            <section className="related-tools card glass" style={{ marginTop: '32px', padding: '24px' }}>
                <h3>Related Tools</h3>
                <div style={{ display: 'flex', gap: '12px', marginTop: '16px', flexWrap: 'wrap' }}>
                    <Link href="/tools/meta-generator" className="btn btn-secondary">Meta Tag Generator <ChevronRight size={14} /></Link>
                    <Link href="/tools/word-counter" className="btn btn-secondary">Word Counter <ChevronRight size={14} /></Link>
                    <Link href="/tools/currency-converter" className="btn btn-secondary">Currency Converter <ChevronRight size={14} /></Link>
                </div>
            </section>
        </div>
        </>
    );
}
