'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { Type, FileText, Zap, HelpCircle, ChevronRight, Lightbulb } from 'lucide-react';

export default function WordCounterPage() {
    const [text, setText] = useState('');

    const stats = {
        words: text.trim() ? text.trim().split(/\s+/).length : 0,
        chars: text.length,
        charsNoSpaces: text.replace(/\s/g, '').length,
        sentences: text.split(/[.!?]+/).filter(Boolean).length,
        paragraphs: text.split(/\n\s*\n/).filter(s => s.trim()).length || (text.trim() ? 1 : 0),
        readingTime: Math.ceil(text.trim().split(/\s+/).length / 200) || 0,
        speakingTime: Math.ceil(text.trim().split(/\s+/).length / 130) || 0,
    };

    const getSEOScore = () => {
        if (stats.words === 0) return null;
        if (stats.words < 300) return { label: 'Too Short', color: '#E53E3E' };
        if (stats.words < 600) return { label: 'Short', color: '#DD6B20' };
        if (stats.words < 1200) return { label: 'Moderate', color: '#D69E2E' };
        if (stats.words <= 2000) return { label: 'Ideal for SEO', color: '#38A169' };
        return { label: 'Long Form', color: '#3182CE' };
    };

    const score = getSEOScore();

    return (
        <div className="tool-container">
            <nav className="breadcrumb">
                <Link href="/">Home</Link> / <span>Word Counter</span>
            </nav>

            <header className="tool-header">
                <div className="tool-category">Text</div>
                <h1>Free <span className="gradient-text">Word Counter</span></h1>
                <p className="tool-intro">
                    Count words, characters, sentences, paragraphs, and estimated reading and speaking time instantly.
                    Includes an SEO content length indicator to help you hit the right word count for Google rankings.
                    Paste any text — results update in real time. No signup, no ads.
                </p>
            </header>

            <div className="tool-layout">
                <div className="tool-main">
                    <div className="card" style={{ padding: '0' }}>
                        <textarea
                            className="word-counter-textarea"
                            placeholder="Paste or type your text here... Results update instantly."
                            value={text}
                            onChange={(e) => setText(e.target.value)}
                        />
                    </div>
                </div>

                <div className="tool-sidebar">
                    <div className="card stats-card">
                        <h3>Content Stats</h3>
                        <div className="stats-list">
                            {[
                                { label: 'Words', value: stats.words.toLocaleString() },
                                { label: 'Characters', value: stats.chars.toLocaleString() },
                                { label: 'Chars (No Spaces)', value: stats.charsNoSpaces.toLocaleString() },
                                { label: 'Sentences', value: stats.sentences.toLocaleString() },
                                { label: 'Paragraphs', value: stats.paragraphs.toLocaleString() },
                            ].map(item => (
                                <div key={item.label} className="stat-row">
                                    <span>{item.label}</span>
                                    <b>{item.value}</b>
                                </div>
                            ))}
                            <div className="stat-row" style={{ borderTop: '1px solid var(--card-border)', marginTop: '12px', paddingTop: '12px' }}>
                                <span>Reading Time</span>
                                <b>~{stats.readingTime} min</b>
                            </div>
                            <div className="stat-row">
                                <span>Speaking Time</span>
                                <b>~{stats.speakingTime} min</b>
                            </div>
                        </div>
                    </div>

                    {score && (
                        <div className="card" style={{ marginTop: '16px', padding: '20px' }}>
                            <h4 style={{ marginBottom: '8px', fontSize: '13px', color: 'var(--text-muted)' }}>SEO Content Length</h4>
                            <span style={{ color: score.color, fontWeight: '700', fontSize: '18px' }}>{score.label}</span>
                            <p style={{ fontSize: '12px', color: 'var(--text-muted)', marginTop: '8px', lineHeight: '1.5' }}>
                                {stats.words < 300 && "Google rarely ranks pages under 300 words. Add more content."}
                                {stats.words >= 300 && stats.words < 600 && "Minimal content. Aim for 600+ words for most topics."}
                                {stats.words >= 600 && stats.words < 1200 && "Decent length. Top rankings usually need 1200+ words."}
                                {stats.words >= 1200 && stats.words <= 2000 && "Great length! Most top-ranking pages are 1200-2000 words."}
                                {stats.words > 2000 && "Long-form content. Excellent for competitive topics and evergreen articles."}
                            </p>
                        </div>
                    )}

                    <div className="card tip-card" style={{ marginTop: '16px' }}>
                        <div className="tip-header">
                            <Lightbulb size={16} color="var(--primary)" />
                            <span>SEO Tip</span>
                        </div>
                        <p>
                            For blog posts targeting competitive keywords, aim for 1,200-1,800 words.
                            Include your main keyword naturally in the first 100 words and in at least one subheading.
                        </p>
                    </div>
                </div>
            </div>

            <section className="card glass" style={{ marginTop: '40px', padding: '32px' }}>
                <h2>Word Count Guidelines for Different Content Types</h2>
                <div style={{ marginTop: '16px', display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))', gap: '16px' }}>
                    {[
                        { type: 'Social Media Post', range: '50-150 words' },
                        { type: 'Product Description', range: '150-300 words' },
                        { type: 'Short Blog Post', range: '500-800 words' },
                        { type: 'Standard Blog Post', range: '1,000-1,500 words' },
                        { type: 'In-Depth Article', range: '1,500-2,500 words' },
                        { type: 'Pillar Page', range: '2,500-5,000 words' },
                    ].map(item => (
                        <div key={item.type} className="card" style={{ padding: '16px' }}>
                            <div style={{ fontWeight: '600', fontSize: '13px' }}>{item.type}</div>
                            <div style={{ color: 'var(--primary)', marginTop: '6px', fontWeight: '700' }}>{item.range}</div>
                        </div>
                    ))}
                </div>
            </section>

            <section className="faq-section" style={{ marginTop: '40px' }}>
                <h2><HelpCircle size={20} style={{ display: 'inline', marginRight: '8px' }} />Frequently Asked Questions</h2>
                <div className="faq-list" style={{ marginTop: '20px' }}>
                    {[
                        { q: "How is word count calculated?", a: "Words are counted by splitting text on whitespace. Hyphenated words count as one word. Numbers count as words. Punctuation is not counted separately." },
                        { q: "What is the ideal word count for SEO?", a: "It depends on the topic. For most informational blog posts, 1,200-2,000 words works well. Competitive topics may need 2,500+. Local business pages can rank with 500-800 words." },
                        { q: "How is reading time calculated?", a: "Reading time is calculated at 200 words per minute, which is the average adult silent reading speed. Speaking time uses 130 words per minute, the average comfortable speaking pace." },
                        { q: "Does word count directly affect SEO rankings?", a: "Word count is not a direct ranking factor, but longer content tends to cover topics more thoroughly, earn more backlinks, and keep visitors on-page longer — all of which do affect rankings." },
                        { q: "Is my text saved anywhere?", a: "No. All processing happens in your browser. Your text is never sent to any server or stored anywhere." },
                    ].map((item, i) => (
                        <details key={i} className="faq-item card" style={{ marginBottom: '12px', padding: '16px 20px' }}>
                            <summary style={{ fontWeight: '600', cursor: 'pointer', listStyle: 'none' }}>
                                <ChevronRight size={16} style={{ display: 'inline', marginRight: '8px' }} />{item.q}
                            </summary>
                            <p style={{ marginTop: '10px', color: 'var(--text-muted)', lineHeight: '1.7' }}>{item.a}</p>
                        </details>
                    ))}
                </div>
            </section>

            <section className="related-tools card glass" style={{ marginTop: '32px', padding: '24px' }}>
                <h3>Related Tools</h3>
                <div style={{ display: 'flex', gap: '12px', marginTop: '16px', flexWrap: 'wrap' }}>
                    <Link href="/tools/meta-generator" className="btn btn-secondary">Meta Tag Generator <ChevronRight size={14} /></Link>
                    <Link href="/tools/image-optimizer" className="btn btn-secondary">Image Optimizer <ChevronRight size={14} /></Link>
                    <Link href="/tools/currency-converter" className="btn btn-secondary">Currency Converter <ChevronRight size={14} /></Link>
                </div>
            </section>

            <style jsx>{`
                .word-counter-textarea { width: 100%; min-height: 400px; background: transparent; border: none; padding: 32px; color: white; font-size: 16px; font-family: inherit; outline: none; resize: vertical; }
                .stats-list { margin-top: 20px; }
                .stat-row { display: flex; justify-content: space-between; margin-bottom: 12px; font-size: 14px; }
                .stat-row span { color: var(--text-muted); }
                .tip-header { display: flex; align-items: center; gap: 8px; margin-bottom: 12px; font-weight: 700; font-size: 14px; }
                .tip-card p { font-size: 13px; color: var(--text-muted); line-height: 1.5; }
            `}</style>
        </div>
    );
}
