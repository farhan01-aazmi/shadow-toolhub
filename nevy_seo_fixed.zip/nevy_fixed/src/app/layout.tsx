import type { Metadata } from "next";
import { Inter, Montserrat } from "next/font/google";
import "./globals.css";
import Navbar from "@/components/layout/Navbar";
import Sidebar from "@/components/layout/Sidebar";
import Footer from "@/components/layout/Footer";

const inter = Inter({
  subsets: ["latin"],
  variable: "--font-inter",
});

const montserrat = Montserrat({
  subsets: ["latin"],
  variable: "--font-montserrat",
  weight: ["400", "700", "800"],
});

export const metadata: Metadata = {
  title: "nevy.in | Free Online Tools — Currency, Crypto, Image & More",
  description: "150+ free online tools for currency conversion, crypto tracking, image optimization, loan calculation and more. No signup, no fees. Works on slow internet too.",
  keywords: ["free online tools", "currency converter", "crypto tracker", "image optimizer", "loan calculator", "free tools India", "nevy.in"],
  authors: [{ name: "nevy.in Team" }],
  metadataBase: new URL("https://www.nevy.in"),
  alternates: {
    canonical: "https://www.nevy.in",
    languages: {
      "en-IN": "https://www.nevy.in",
      "hi-IN": "https://www.nevy.in",
    },
  },
  openGraph: {
    title: "nevy.in | Free Online Tools",
    description: "150+ free online tools. No signup, no fees. Ever.",
    url: "https://www.nevy.in",
    siteName: "nevy.in",
    locale: "en_IN",
    type: "website",
  },
  robots: "index, follow",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <head>
        <link rel="alternate" hrefLang="en-in" href="https://www.nevy.in" />
        <link rel="alternate" hrefLang="hi-in" href="https://www.nevy.in" />
        <link rel="alternate" hrefLang="x-default" href="https://www.nevy.in" />
      </head>
      <body className={`${inter.variable} ${montserrat.variable}`}>
        <Navbar />
        <div className="layout-container">
          <Sidebar />
          <main className="main-content">
            {children}
            <Footer />
          </main>
        </div>
      </body>
    </html>
  );
}
