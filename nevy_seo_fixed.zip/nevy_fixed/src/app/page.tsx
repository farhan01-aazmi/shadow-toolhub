import Link from "next/link";
import type { Metadata } from "next";
import {
  Zap,
  ArrowRight,
  Calculator,
  Coins,
  Image as ImageIcon,
  FileText,
  Shield,
  Globe,
  Lock
} from "lucide-react";

export const metadata: Metadata = {
  title: "nevy.in — Free Online Tools. No Signup. No Fees.",
  description: "150+ free online tools — currency converter, crypto tracker, image optimizer, loan calculator, word counter and more. No signup, no fees, 100% browser-based.",
  alternates: { canonical: "https://www.nevy.in" },
};

export default function Home() {
  const featuredTools = [
    {
      name: "Currency Converter",
      desc: "Real-time exchange rates for 150+ currencies. Fast and accurate.",
      icon: <Calculator className="text-primary" />,
      href: "/tools/currency-converter",
      category: "Finance"
    },
    {
      name: "Crypto Tracker",
      desc: "Live prices for top 50+ cryptocurrencies via CoinGecko.",
      icon: <Coins className="text-secondary" />,
      href: "/tools/crypto-tracker",
      category: "Crypto"
    },
    {
      name: "Image Optimizer",
      desc: "Compress and convert images to WebP — 100% in your browser.",
      icon: <ImageIcon className="text-accent" />,
      href: "/tools/image-optimizer",
      category: "Image"
    },
    {
      name: "Loan Calculator",
      desc: "Calculate EMI, total interest and payment schedule instantly.",
      icon: <Calculator className="text-primary" />,
      href: "/tools/loan-calculator",
      category: "Finance"
    },
    {
      name: "Word Counter",
      desc: "Count words, characters, sentences and reading time instantly.",
      icon: <FileText className="text-secondary" />,
      href: "/tools/word-counter",
      category: "Text"
    },
    {
      name: "Meta Generator",
      desc: "Generate SEO-optimized meta titles and descriptions for any page.",
      icon: <Zap className="text-accent" />,
      href: "/tools/meta-generator",
      category: "SEO"
    },
  ];

  return (
    <div className="home-container">
      {/* Hero Section */}
      <section className="hero">
        <div className="badge glass">
          <Zap size={14} /> <span>150+ Free Tools</span>
        </div>
        <h1 className="hero-title">
          Tools that <span className="gradient-text">actually work.</span>
        </h1>
        <p className="hero-subtitle">
          nevy.in offers 150+ free online tools — currency conversion, crypto tracking,
          image optimization, loan calculation and more. No signup, no fees. Ever.
          Works on slow internet too.
        </p>
        <div className="hero-actions">
          <Link href="/tools/currency-converter" className="btn btn-primary">
            Explore Tools <ArrowRight size={18} />
          </Link>
          <Link href="/about" className="btn btn-secondary glass">
            About nevy.in
          </Link>
        </div>
      </section>

      {/* Stats Bar */}
      <section className="stats-bar glass">
        <div className="stat-item">
          <Zap size={20} />
          <span><b>150+</b> Free Tools</span>
        </div>
        <div className="stat-item">
          <Globe size={20} />
          <span><b>No</b> Signup Required</span>
        </div>
        <div className="stat-item">
          <Lock size={20} />
          <span><b>100%</b> Browser-Based</span>
        </div>
        <div className="stat-item">
          <Shield size={20} />
          <span><b>Zero</b> Fees. Always.</span>
        </div>
      </section>

      {/* Featured Tools Grid */}
      <section className="featured-section">
        <div className="section-header">
          <h2 className="section-title">Popular Tools</h2>
          <p className="section-desc">Fast, free, and privacy-first tools for your daily needs.</p>
        </div>

        <div className="tools-grid">
          {featuredTools.map((tool) => (
            <Link href={tool.href} key={tool.name} className="tool-card card">
              <div className="tool-icon-wrapper">
                {tool.icon}
              </div>
              <div className="tool-category">{tool.category}</div>
              <h3>{tool.name}</h3>
              <p>{tool.desc}</p>
              <div className="tool-action">
                <span>Use Tool</span>
                <ArrowRight size={16} />
              </div>
            </Link>
          ))}
        </div>
      </section>

      {/* Blog Teaser */}
      <section className="blog-teaser-section">
        <div className="section-header">
          <h2 className="section-title">Guides & Tips</h2>
          <p className="section-desc">Learn how to use our tools and get the most out of them.</p>
        </div>

        <div className="blog-mini-grid">
          <Link href="/blog/mastering-currency-exchange-rates-2026" className="blog-mini-card card glass">
            <h4>Mastering Global Currency in 2026</h4>
            <span className="read-more">Read Guide <ArrowRight size={14} /></span>
          </Link>
          <Link href="/blog/crypto-market-survival-guide" className="blog-mini-card card glass">
            <h4>Crypto Market Survival Guide</h4>
            <span className="read-more">Read Guide <ArrowRight size={14} /></span>
          </Link>
        </div>
      </section>

    </div>
  );
}
