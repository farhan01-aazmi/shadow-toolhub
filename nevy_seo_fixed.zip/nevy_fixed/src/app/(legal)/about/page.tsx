import { Metadata } from 'next';
import { Target, Heart, ShieldCheck, Mail, MapPin } from 'lucide-react';

export const metadata: Metadata = {
    title: "About Us | nevy.in — Free Online Tools",
    description: "Learn about nevy.in — a free, no-signup platform with 150+ online tools for currency conversion, image optimization, calculators, crypto tracking and more. Built for everyone.",
    alternates: { canonical: "https://www.nevy.in/about" },
};

export default function AboutPage() {
    return (
        <div className="legal-container">
            <header className="legal-header">
                <h1 className="gradient-text">About nevy.in</h1>
                <p className="legal-intro">
                    Free tools for everyone. No signup. No fees. No nonsense.
                </p>
            </header>

            <div className="legal-content card glass">
                <section className="about-section">
                    <h2>Our Story</h2>
                    <p>
                        nevy.in was created in 2025 with a simple idea: people should not have to pay, sign up,
                        or share personal data just to use basic online tools. We built a suite of 150+ free tools
                        covering currency conversion, image optimization, loan calculations, crypto tracking, and more —
                        all running directly in your browser.
                    </p>
                </section>

                <section className="about-section">
                    <h2>What We Offer</h2>
                    <p>
                        From financial calculators and image compressors to crypto trackers and SEO tools —
                        nevy.in covers everything you need for daily digital tasks. All tools are free,
                        fast, and work on slow internet too.
                    </p>
                </section>

                <div className="values-grid">
                    <div className="value-item">
                        <Target size={24} className="text-primary" />
                        <div>
                            <h3>Always Free</h3>
                            <p>No paywalls, no subscriptions. Every tool on nevy.in is and will always be 100% free.</p>
                        </div>
                    </div>
                    <div className="value-item">
                        <Heart size={24} className="text-secondary" />
                        <div>
                            <h3>No Signup Required</h3>
                            <p>Use any tool instantly — no account, no email, no credit card needed.</p>
                        </div>
                    </div>
                    <div className="value-item">
                        <ShieldCheck size={24} className="text-accent" />
                        <div>
                            <h3>Privacy First</h3>
                            <p>Your files and data never leave your device. All processing happens in your browser.</p>
                        </div>
                    </div>
                </div>

                <section className="about-section">
                    <h2>Get in Touch</h2>
                    <p style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                        <Mail size={16} /> support@nevy.in
                    </p>
                    <p style={{ display: 'flex', alignItems: 'center', gap: '8px', marginTop: '8px' }}>
                        <MapPin size={16} /> Mumbai, Maharashtra, India
                    </p>
                </section>
            </div>
        </div>
    );
}
