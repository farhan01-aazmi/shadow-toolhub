import { Metadata } from 'next';
import Link from 'next/link';
import { getProgrammaticPosts } from '@/lib/blog/generator';
import StructuredData from '@/components/seo/StructuredData';
import { ArrowRight, Calendar, ChevronRight } from 'lucide-react';

export const metadata: Metadata = {
    title: "Blog — Free Tools Guides, Finance Tips & SEO Tutorials | nevy.in",
    description: "Practical guides on currency conversion, EMI calculation, image optimization, crypto tracking, and SEO meta tags. Free tutorials from the nevy.in team.",
    alternates: { canonical: "https://www.nevy.in/blog" },
};

export default async function BlogListingPage() {
    const posts = await getProgrammaticPosts();

    const blogSchema = {
        "@context": "https://schema.org",
        "@type": "Blog",
        "name": "nevy.in Blog",
        "url": "https://www.nevy.in/blog",
        "description": "Guides and tutorials on free online tools, finance, crypto, image optimization, and SEO.",
        "publisher": { "@type": "Organization", "name": "nevy.in", "url": "https://www.nevy.in" }
    };

    const categories = [...new Set(posts.map(p => p.category))];

    return (
        <>
        <StructuredData data={blogSchema} />
        <div className="blog-container">
            <nav className="breadcrumb">
                <Link href="/">Home</Link> / <span>Blog</span>
            </nav>

            <header className="blog-header">
                <h1 className="gradient-text">Guides & Tutorials</h1>
                <p className="blog-intro">
                    Practical, no-fluff guides on how to use free online tools, understand financial concepts,
                    optimize your website, and track cryptocurrency — written by the nevy.in team.
                </p>
                <div style={{ display: 'flex', gap: '8px', marginTop: '16px', flexWrap: 'wrap' }}>
                    {categories.map(cat => (
                        <span key={cat} style={{ background: 'var(--primary-glow)', color: 'var(--primary)', padding: '4px 12px', borderRadius: '20px', fontSize: '13px', fontWeight: '600' }}>{cat}</span>
                    ))}
                </div>
            </header>

            <div className="posts-grid">
                {posts.map((post) => (
                    <article key={post.slug} className="post-card card glass">
                        <div className="post-meta">
                            <span className="category-tag">{post.category}</span>
                            <span className="date-meta">
                                <Calendar size={14} /> {new Date(post.date).toLocaleDateString('en-IN', { day: 'numeric', month: 'long', year: 'numeric' })}
                            </span>
                        </div>
                        <h2 style={{ fontSize: '18px', marginTop: '12px', lineHeight: '1.5' }}>
                            <Link href={`/blog/${post.slug}`} style={{ color: 'inherit', textDecoration: 'none' }}>{post.title}</Link>
                        </h2>
                        <p style={{ marginTop: '10px', color: 'var(--text-muted)', lineHeight: '1.7', fontSize: '14px' }}>{post.excerpt}</p>
                        <div style={{ display: 'flex', gap: '8px', marginTop: '12px', flexWrap: 'wrap' }}>
                            {post.tags.map(tag => (
                                <span key={tag} style={{ background: 'rgba(255,255,255,0.05)', padding: '2px 10px', borderRadius: '4px', fontSize: '12px', color: 'var(--text-muted)' }}>#{tag}</span>
                            ))}
                        </div>
                        <Link href={`/blog/${post.slug}`} className="read-more" style={{ display: 'flex', alignItems: 'center', gap: '6px', marginTop: '16px', color: 'var(--primary)', fontWeight: '600', fontSize: '14px', textDecoration: 'none' }}>
                            Read Guide <ArrowRight size={14} />
                        </Link>
                    </article>
                ))}
            </div>

            <section className="card glass" style={{ marginTop: '48px', padding: '32px' }}>
                <h2>Explore Our Free Tools</h2>
                <p style={{ marginTop: '12px', color: 'var(--text-muted)', lineHeight: '1.7' }}>
                    All tools mentioned in our guides are free to use on nevy.in — no signup, no fees, no data collection.
                </p>
                <div style={{ display: 'flex', gap: '12px', marginTop: '20px', flexWrap: 'wrap' }}>
                    <Link href="/tools/currency-converter" className="btn btn-secondary">Currency Converter <ChevronRight size={14} /></Link>
                    <Link href="/tools/loan-calculator" className="btn btn-secondary">EMI Calculator <ChevronRight size={14} /></Link>
                    <Link href="/tools/image-optimizer" className="btn btn-secondary">Image Optimizer <ChevronRight size={14} /></Link>
                    <Link href="/tools/crypto-tracker" className="btn btn-secondary">Crypto Tracker <ChevronRight size={14} /></Link>
                    <Link href="/tools/meta-generator" className="btn btn-secondary">Meta Generator <ChevronRight size={14} /></Link>
                </div>
            </section>
        </div>
        </>
    );
}
