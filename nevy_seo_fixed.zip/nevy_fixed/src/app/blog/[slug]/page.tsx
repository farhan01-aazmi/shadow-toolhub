import { Metadata } from 'next';
import { notFound } from 'next/navigation';
import { getProgrammaticPosts, getPostBySlug } from '@/lib/blog/generator';
import StructuredData from '@/components/seo/StructuredData';
import Link from 'next/link';
import { ArrowLeft, Calendar, User, Tag, ChevronRight } from 'lucide-react';

interface Props { params: { slug: string }; }

export async function generateStaticParams() {
    const posts = await getProgrammaticPosts();
    return posts.map(post => ({ slug: post.slug }));
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
    const post = await getPostBySlug((await params).slug);
    if (!post) return { title: 'Post Not Found' };
    return {
        title: `${post.title} | nevy.in Blog`,
        description: post.excerpt,
        keywords: post.tags.join(', '),
        alternates: { canonical: `https://www.nevy.in/blog/${post.slug}` },
        openGraph: {
            title: post.title,
            description: post.excerpt,
            type: 'article',
            publishedTime: post.date,
            authors: [post.author],
        }
    };
}

export default async function BlogPostPage({ params }: Props) {
    const post = await getPostBySlug((await params).slug);
    if (!post) notFound();

    const allPosts = await getProgrammaticPosts();
    const related = allPosts.filter(p => p.slug !== post.slug && p.category === post.category).slice(0, 2);

    const articleSchema = {
        "@context": "https://schema.org",
        "@type": "Article",
        "headline": post.title,
        "description": post.excerpt,
        "author": { "@type": "Organization", "name": post.author },
        "publisher": { "@type": "Organization", "name": "nevy.in", "url": "https://www.nevy.in" },
        "datePublished": post.date,
        "dateModified": post.date,
        "url": `https://www.nevy.in/blog/${post.slug}`,
        "keywords": post.tags.join(', '),
    };

    return (
        <>
        <StructuredData data={articleSchema} />
        <div className="blog-post-container">
            <nav className="breadcrumb">
                <Link href="/">Home</Link> / <Link href="/blog">Blog</Link> / <span>{post.title}</span>
            </nav>

            <Link href="/blog" className="back-link" style={{ display: 'inline-flex', alignItems: 'center', gap: '6px', color: 'var(--primary)', textDecoration: 'none', marginBottom: '24px', fontSize: '14px', fontWeight: '600' }}>
                <ArrowLeft size={16} /> Back to All Guides
            </Link>

            <article>
                <header style={{ marginBottom: '32px' }}>
                    <span className="category-tag">{post.category}</span>
                    <h1 style={{ fontSize: '28px', lineHeight: '1.4', marginTop: '16px', fontWeight: '800' }}>{post.title}</h1>
                    <p style={{ color: 'var(--text-muted)', marginTop: '12px', fontSize: '16px', lineHeight: '1.6' }}>{post.excerpt}</p>
                    <div style={{ display: 'flex', gap: '20px', marginTop: '16px', fontSize: '13px', color: 'var(--text-muted)', flexWrap: 'wrap' }}>
                        <span style={{ display: 'flex', alignItems: 'center', gap: '6px' }}><Calendar size={14} /> {new Date(post.date).toLocaleDateString('en-IN', { day: 'numeric', month: 'long', year: 'numeric' })}</span>
                        <span style={{ display: 'flex', alignItems: 'center', gap: '6px' }}><User size={14} /> {post.author}</span>
                    </div>
                    <div style={{ display: 'flex', gap: '8px', marginTop: '12px', flexWrap: 'wrap' }}>
                        {post.tags.map(tag => (
                            <span key={tag} style={{ background: 'rgba(255,255,255,0.05)', padding: '2px 10px', borderRadius: '4px', fontSize: '12px', color: 'var(--text-muted)' }}>
                                <Tag size={10} style={{ display: 'inline', marginRight: '4px' }} />{tag}
                            </span>
                        ))}
                    </div>
                </header>

                <div className="post-content card glass" style={{ padding: '32px', lineHeight: '1.8', fontSize: '15px' }}
                    dangerouslySetInnerHTML={{ __html: post.content }}
                />
            </article>

            {related.length > 0 && (
                <section style={{ marginTop: '48px' }}>
                    <h2 style={{ fontSize: '20px', fontWeight: '700', marginBottom: '20px' }}>Related Guides</h2>
                    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))', gap: '16px' }}>
                        {related.map(p => (
                            <Link key={p.slug} href={`/blog/${p.slug}`} className="card glass" style={{ padding: '20px', textDecoration: 'none', color: 'inherit' }}>
                                <span className="category-tag">{p.category}</span>
                                <h3 style={{ fontSize: '15px', marginTop: '10px', lineHeight: '1.5' }}>{p.title}</h3>
                                <span style={{ color: 'var(--primary)', fontSize: '13px', fontWeight: '600', marginTop: '12px', display: 'inline-flex', alignItems: 'center', gap: '4px' }}>Read Guide <ChevronRight size={13} /></span>
                            </Link>
                        ))}
                    </div>
                </section>
            )}

            <section className="card glass" style={{ marginTop: '40px', padding: '24px' }}>
                <h3>Explore Free Tools</h3>
                <div style={{ display: 'flex', gap: '12px', marginTop: '16px', flexWrap: 'wrap' }}>
                    <Link href="/tools/currency-converter" className="btn btn-secondary">Currency Converter <ChevronRight size={14} /></Link>
                    <Link href="/tools/loan-calculator" className="btn btn-secondary">EMI Calculator <ChevronRight size={14} /></Link>
                    <Link href="/tools/image-optimizer" className="btn btn-secondary">Image Optimizer <ChevronRight size={14} /></Link>
                    <Link href="/tools/crypto-tracker" className="btn btn-secondary">Crypto Tracker <ChevronRight size={14} /></Link>
                </div>
            </section>
        </div>
        </>
    );
}
